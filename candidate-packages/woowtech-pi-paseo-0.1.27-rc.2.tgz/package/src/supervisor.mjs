import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {DefaultPackageManager, SettingsManager} from '@earendil-works/pi-coding-agent';
import * as runtime from './runtime.mjs';
import {SUPERVISOR_STOP_TIMEOUT_MS} from './lifecycle-timeouts.mjs';
import {processIdentity, assertSafePath} from './state.mjs';
import { readRecord, writeRecord, withLock } from './onboarding.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
// A supervisor keeps running the code it was started with. After an in-place upgrade (the same
// packageRoot) one recorded under another plugin version, or under none (0.1.23 and earlier), would
// still call its own activate() when the daemon exits, and start the release it shipped with.
const VERSION=(()=>{try{const version=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version;return typeof version==='string'?version:null;}catch{return null;}})();
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function alive(pid) {try{process.kill(pid,0);return true;}catch{return false;}}
function sameProcess(record) {
 if (!Number.isInteger(record.pid)||record.pid<=1||typeof record.packageRoot!=='string'||!path.isAbsolute(record.packageRoot)||!alive(record.pid)||!record.identity||processIdentity(record.pid)!==record.identity) return false;
 try {
  const args=fs.readFileSync('/proc/'+record.pid+'/cmdline','utf8').split('\0');
  return args.includes(path.join(record.packageRoot,'bin/cli.mjs'))&&args.includes('supervise');
 } catch{return process.platform!=='linux'&&record.packageRoot===root;}
}
/** Signals the supervisor that `record` names, if that process is still that supervisor, and waits for it to end.
 * True when it was one that had to be stopped. */
async function stopOwnedSupervisor(record,timeoutMs) {
 if(!sameProcess(record))return false;
 try {process.kill(record.pid,'SIGTERM');} catch(error) {if(error.code!=='ESRCH')throw error;}
 const deadline=Date.now()+timeoutMs;
 while(sameProcess(record)) {
  if(Date.now()>=deadline)throw new Error('Plugin supervisor is still stopping');
  await delay(Math.min(100,Math.max(1,deadline-Date.now())));
 }
 return true;
}
// How a supervisor's own stop of the daemon went. The host that signals it for a disable only waits for the process
// to end and cannot see an error thrown inside it, so a failed stop is written down (stopSupervisor reads it).
const stopFile=loc=>path.join(loc.stateDir,'supervisor-stop.json');
const safeCode=value=>/^[A-Z][A-Z0-9_]{0,63}$/.test(value||'')?value:null;
function recordStop(loc,outcome) {
 try {writeRecord(stopFile(loc),{pid:process.pid,at:new Date().toISOString(),...outcome});} catch { /* the stop is what counts, not its record */ }
}
async function stopDaemon(loc) {
 try {const result=await runtime.deactivate();recordStop(loc,{ok:true});return result;}
 catch(error) {recordStop(loc,{ok:false,code:safeCode(error?.code)||'OPERATION_FAILED'});throw error;}
}
function sameRoot(installedPath) {
 if(typeof installedPath!=='string')return false;
 try{return fs.realpathSync(installedPath)===fs.realpathSync(root);}catch{return false;}
}
export function packageEnabled(loc=runtime.locations(),{cwd}={}) {
 const registration=readRecord(path.join(loc.stateDir,'host-registration.json'));
 // Service stop is independent of whether Pi still has the package enabled.
 if(registration.enabled===false)return false;
 cwd=cwd||registration.cwd||process.cwd();
 const settings=SettingsManager.create(cwd,loc.agentDir);
 const manager=new DefaultPackageManager({cwd,agentDir:loc.agentDir,settingsManager:settings});
 const scopes={user:settings.getGlobalSettings(),project:settings.getProjectSettings()};
 return manager.listConfiguredPackages().some(pkg=>{
  if(!sameRoot(pkg.installedPath))return false;
  const entry=(scopes[pkg.scope].packages||[]).find(p=>(typeof p==='string'?p:p.source)===pkg.source);
  return typeof entry==='string'||!!entry&&(!Array.isArray(entry.extensions)||entry.extensions.length>0);
 });
}
// Does this exit mean "the user wants Paseo off"? Only the host knows, and it records
// its intent in host-registration.json before it signals:
//   * enabled === false  -> a real disable; finish it even if the host's waiter died.
//   * packageRoot is some OTHER root -> this supervisor is being REPLACED by one under
//     that root (a plugin-source swap, e.g. repinning a git tag to the image bundle).
//     packageEnabled() would say false here only because Pi no longer configures *our*
//     root, which is not a user disable.
//   * otherwise -> Pi itself no longer has the package enabled, so disable.
// BOTH exits have to ask this: the signal path in finally, and the loop below when it
// finds Pi no longer configuring our root. 0.1.14 guarded only the signal path, so a
// source swap the loop noticed by itself still persisted a disable -- the very outcome
// this reasoning exists to prevent (#13).
// Reading Pi's settings or the record can throw; an exit path must not mask the real
// error, and "cannot tell" has to mean "leave the user's choice alone".
function shouldDeactivate(loc) {
 try {
  const registration=readRecord(path.join(loc.stateDir,'host-registration.json'));
  if(registration.enabled===false)return true;
  if(typeof registration.packageRoot==='string'&&!sameRoot(registration.packageRoot))return false;
  return !packageEnabled(loc);
 } catch {return false;}
}
/** @param {{cwd?: string}} [options] */
export async function startSupervisor({cwd}={}) {
 const loc=runtime.locations(),file=path.join(loc.stateDir,'supervisor.json');
 return withLock(path.join(loc.stateDir,'supervisor-start.lock'),async()=>{
  if(!packageEnabled(loc,{cwd}))return {running:false};
  const old=readRecord(file);
  if(sameProcess(old)) {
   // Kept only when it runs this root at this version. A version this module cannot read leaves the
   // previous rule (same root) in place. Replacement goes through the same ownership checks.
   if(old.packageRoot===root&&(VERSION===null||old.version===VERSION))return {running:true,pid:old.pid};
   await stopOwnedSupervisor(old,SUPERVISOR_STOP_TIMEOUT_MS);
  }
  const logFile=path.join(loc.stateDir,'supervisor.log');
  assertSafePath(logFile);
  const log=fs.openSync(logFile,fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_APPEND|fs.constants.O_NOFOLLOW,0o600);
  let child;
  try {
   fs.fchmodSync(log,0o600);
   child=spawn(process.execPath,[path.join(root,'bin/cli.mjs'),'supervise'],{cwd:cwd||readRecord(path.join(loc.stateDir,'host-registration.json')).cwd||process.cwd(),detached:true,stdio:['ignore',log,log],env:process.env});
  } finally {fs.closeSync(log);}
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});
  writeRecord(file,{pid:child.pid,identity:processIdentity(child.pid),packageRoot:root,...(VERSION===null?{}:{version:VERSION}),startedAt:new Date().toISOString()});child.unref();
  return {running:true,pid:child.pid};
 });
}
/** Stops the plugin supervisor. When it ends for a disable it stops the daemon itself; if that failed, the result
 * carries the failure ({stopped: true, failed: {code, at}}) so the caller does not wait out the same budget again. */
export async function stopSupervisor({timeoutMs=SUPERVISOR_STOP_TIMEOUT_MS}={}) {
 const loc=runtime.locations(),began=Date.now();
 return withLock(path.join(loc.stateDir,'supervisor-start.lock'),async()=>{
  const record=readRecord(path.join(loc.stateDir,'supervisor.json'));
  if(!await stopOwnedSupervisor(record,timeoutMs))return {stopped:true};
  let outcome;try {outcome=readRecord(stopFile(loc));} catch {outcome={};}
  // Its own record: this supervisor's, written during this stop.
  const failed=outcome.ok===false&&outcome.pid===record.pid&&Date.parse(outcome.at)>=began;
  return failed?{stopped:true,failed:{code:safeCode(outcome.code)||'OPERATION_FAILED',at:outcome.at}}:{stopped:true};
 });
}
export async function supervise() {
 const loc=runtime.locations();
 let stop=false,initialized=false,retries=0,wake,refreshing;
 const shutdown=()=>{stop=true;runtime.abortPruning();wake?.();};
 const wait=ms=>new Promise(resolve=>{
  if(stop){resolve();return;}
  const timer=setTimeout(done,ms);
  function done(){clearTimeout(timer);wake=undefined;resolve();}
  wake=done;
 });
 process.once('SIGTERM',shutdown);process.once('SIGINT',shutdown);
 // Pi no longer configuring our root always ends this supervisor -- but ending and leaving
 // Paseo disabled are two decisions, so only the first one is settled here.
 const unconfigured=async()=>{
  if(packageEnabled(loc))return false;
  if(shouldDeactivate(loc))await stopDaemon(loc);
  return true;
 };
 try {
  while(!stop) {
   if(await unconfigured())break;
   try {
    // The PID lock and /proc only: answering a daemon status request makes Paseo run every provider's --version.
    const running=await runtime.daemonRunning();
    if(stop)break;
    if(await unconfigured())break;
    if(!initialized||!running) {await runtime.activate();initialized=true;}
    // Not awaited: the daemon finishes a Pi catalog refresh on its own, so it must not hold up this loop or a stop.
    else refreshing??=runtime.refreshPiCatalogIfChanged().catch(()=>false).finally(()=>{refreshing=undefined;});
    if(stop)break;
    if(await unconfigured())break;
    retries=0;
   } catch(e) {
    // Keep only an error class; providers and pairing output can carry credentials.
    writeRecord(path.join(loc.stateDir,'supervisor-error.json'),{kind:e?.name||'Error',at:new Date().toISOString(),retry:++retries});
   }
   await wait(Math.min(15000*Math.max(retries,1),60000));
  }
 } finally {
  process.removeListener('SIGTERM',shutdown);process.removeListener('SIGINT',shutdown);
  // However this supervisor ends, a delete of old releases it started must not keep the process alive: only the success path
  // of `supervise` in bin/cli.mjs calls process.exit, and one that ends on a failed stop below would otherwise wait for it.
  runtime.abortPruning();
  // A signal only means this process must end; whether Paseo should be left disabled
  // is a separate question (see shouldDeactivate). Deactivating on every stop
  // persisted "the user wants Paseo off" for a container shutdown or a source swap.
  if(stop&&shouldDeactivate(loc))await stopDaemon(loc);
 }
}
